DROP TABLE expense;
DROP TABLE expense_share;
DROP TABLE partecipate;
DROP TABLE project;
DROP TABLE share;
DROP TABLE user;