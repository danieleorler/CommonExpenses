package com.dalendev.ce.util;

public class WebConfig
{

	public static final String APP_NAME = "ce";
	public static final String ASSETS_FOLDER = "/"+APP_NAME+"/assets/";
	
}
